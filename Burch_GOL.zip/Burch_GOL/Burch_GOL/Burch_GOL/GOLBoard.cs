﻿using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;


/// <summary>
/// Brendan Burch | 244 | 03.07.2018|
/// 
/// GAME OF LIFE: Make a  grid of alive and dead cells generated randomly, 
/// alive and dead cells determined by value of neighboring cells,
/// shows aging cells based on color,
/// able to save patterns as files.
/// </summary>

namespace Burch_GOL
{
    public partial class GOLBoard : Form
    {
        private Graphics gr; //graphics object//
        private Pen pen; //pen object//
        private Brush brush;//brush object//

        public const int ROWS = 42;//constant variable for 42 rows//
        public const int COLS = 62;//constant variable for 62 columns//

        public const int RECT_WIDTH = 9;//constant var for dimension//
        public const int RECT_HEIGHT = 9;//constant var for dimension//

        //two dimensional array of cells representing the grid//
        public GOLCell[,] board;

        //random generator
        public Random gen;

        //alive, dead cell, and generation counters//
        private int generation;
        private int aliveCells;
        private int deadCells;

        //Generation label Variables//
        private int emptyCells = 0;
        private int genOne = 0;
        private int genTwo = 0;
        private int genThree = 0;
        private int genFour = 0;
        private int genFive = 0;

        StreamReader ReadIn;
        StreamWriter Writer;


        // GOL Constructor //
        public GOLBoard()
        {
            InitializeComponent();
           
            

            gr = panGrid.CreateGraphics();//creates graphics//

            board = new GOLCell[ROWS, COLS];//instantiate 2D array//
            pen = new Pen(Color.Black); //instantiate pen with color//
            brush = new SolidBrush(Color.White);//instantiate brush with color//

            gen = new Random();//instantiated random generator//

        }

        //Creates grid using loops//
        public void createGrid(bool genRandom)
        {
            for (int i = 0; i < ROWS; i++) // represents y coordinates on grid//
            {
                for (int j = 0; j < COLS; j++) //represents x coordinates on grid//
                {
                    //creates new rectangle with given values//
                    Rectangle rect = new Rectangle(j * RECT_WIDTH, i * RECT_HEIGHT, RECT_HEIGHT, RECT_WIDTH);
                    gr.FillRectangle(brush, rect);//fills rectangle//
                    gr.DrawRectangle(pen, rect);//draws cells//

                    int alive;
                    //determines if a cell is alive or dead//
                    if (genRandom == true)
                    {
                        alive = determineCellLife();
                    }
                    else
                    {
                        alive = 0;
                    }


                    //creates new GOL object//                 
                    board[i, j] = new GOLCell();
                    board[i, j].Cell = rect;
                    board[i, j].IsAlive = alive;
                }
            }
        }

        //Updates grid
        //paints alive cells yellow; adds alive cells to counter lable
        //paints dead cells white; adds dead cells to dead counter lable
        public void updateGrid()
        {
            panGrid.Controls.Clear();


            for (int i = 0; i < ROWS; i++)
            {
                for (int j = 0; j < COLS; j++)
                {
                    board[i, j].ChangeFutureToCurrent();
                    SolidBrush Brush = new SolidBrush(board[i, j].DetermineColor());
                    gr.FillRectangle(Brush, board[i, j].Cell);
                    gr.DrawRectangle(pen, board[i, j].Cell);
                }
            }
            GenCounter();

        }

        //method to determine cell life//
        public int determineCellLife()
        {
            //returns alive or dead as a int statement to create grade//
            return gen.Next(0, 2);
        }

        //method determines next generation//
        public void NextGen()
        {
            for (int i = 1; i < ROWS - 1; i++)
            {

                for (int j = 1; j < COLS - 1; j++)
                {
                    // aliveneighbors calls surroundingCells()//
                    int aliveNeighbors = surroundingCells(i, j);


                    //checks if cell has exactly 2 alive cell neighbors, cell must also be alive
                    //or checks if it has any three neighboring cells
                    if ((aliveNeighbors == 2 && board[i, j].IsAlive == 1) || (aliveNeighbors == 3))
                    {
                        board[i, j].FutureState = 1;
                        aliveCells++;
                    }
                    //brings cell to life 
                    else if (board[i, j].IsAlive == 1)
                    {
                        board[i, j].FutureState = 0;
                        deadCells++;
                    }
                    //else kills cell
                    else
                    {
                        board[i, j].FutureState = 0;
                    }
                }
            }
        }

        //method takes the location of a cell and returns the number of neighbors//
        public int surroundingCells(int i, int j)
        {
            return board[i - 1, j].IsAlive + board[i - 1, j - 1].IsAlive + board[i, j - 1].IsAlive + board[i + 1, j].IsAlive + board[i + 1, j + 1].IsAlive +
                board[i, j + 1].IsAlive + board[i - 1, j + 1].IsAlive + board[i + 1, j - 1].IsAlive;
        }

        //method for incrementing generation counters//
        public void GenCounter()
        {
            for (int i = 0; i < ROWS; i++)
            {
                for (int j = 0; j < COLS; j++)
                {
                    //generation increment for each case//
                    switch (board[i, j].Age)
                    {
                        case 0:
                            emptyCells++;
                            break;
                        case 1:
                            genOne++;
                            break;
                        case 2:
                            genTwo++;
                            break;
                        case 3:
                            genThree++;
                            break;
                        case 4:
                            genFour++;
                            break;
                        default:
                            genFive++;
                            break;

                    }
                }
            }
        }

         // --Labels---\\

       //sets labels that dont increment on base pattern--depending on toggle generation//
        public void baseLbl()
        {

            generation++;
     

            lblGen.Text = "Generation: " + generation;
            lblWhite.Text = "Empty Cells: " + emptyCells;
            lblYellow.Text = "Generation 1: " + genOne;
            lblGreen.Text = "Generation 2: " + genTwo;
            lblBlue.Text = "Generation 3: " + genThree;
            lblMagenta.Text = "Generation 4: " + genFour;
            lblRed.Text = "Generation 5+: " + genFive;

            //resets each label to 0 after each generation prevents stacking generation #'s//
            emptyCells = 0;
            genOne = 0;
            genTwo = 0;
            genThree = 0;
            genFour = 0;
            genFive = 0;
        }

        //resets to clean grid//
        public void ResetGrid(bool resetLblsOnly)
        {
            if (resetLblsOnly == false)
            {
                createGrid(false);//creates new empty grid
            }
            
            //reset all label and values to zero//
            generation = 0;
            emptyCells = 0;
            genOne = 0;
            genTwo = 0;
            genThree = 0;
            genFour = 0;
            genFive = 0;
            lblGen.Text = "Generation: " + generation;
            lblWhite.Text = "Empty Cells: " + emptyCells;
            lblYellow.Text = "Generation 1: " + genOne;
            lblGreen.Text = "Generation 2: " + genTwo;
            lblBlue.Text = "Generation 3: " + genThree;
            lblMagenta.Text = "Generation 4: " + genFour;
            lblRed.Text = "5+ Generations: " + genFive;
        }

        
        // --Pattern Methods-- \\
      
        //method containing pulsar pattern//
        private void pulsar()
        {
            //create new grid//
            createGrid(false);
            //new 2-D array of pulse pattern//
            int[,] pulse = {{ 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0 },
                           { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                           { 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
                           { 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
                           { 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
                           { 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0 },
                           { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                           { 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0 },
                           { 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
                           { 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
                           { 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
                           { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                           { 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0 }};

            //loop to specific section of grid --inserts pulse//
            for (int i = 0; i < 13; i++)
            {
                for (int j = 0; j < 13; j++)
                {
                    //sets up board[i,j] for futurestate if toggle button is clicked//
                    board[i + 15, j + 23].FutureState = pulse[i, j];
                }
            }
            //calls update grid after board is set//
            updateGrid();

        }

        //method for creating beacon pattern//
        private void beacon()
        {
            createGrid(false);

            int[,] beacon = {{ 0, 0, 0, 0, 0, 0 },
                             { 0, 1, 1, 0, 0, 0 },
                             { 0, 1, 0, 0, 0, 0 },
                             { 0, 0, 0, 0, 1, 0 },
                             { 0, 0, 0, 1, 1, 0 },
                             { 0, 0, 0, 0, 0, 0 }};

            //loop to specific section of board[i,j] array--inserts beacon//
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    //sets up board[i,j] for futurestate if toggle button is clicked//
                    board[i + 16, j + 26].FutureState = beacon[i, j];
                }
            }
            updateGrid();
        }
        //pattern for infinite growth//
        private void infinite()
        {
            createGrid(false);

            int[] inf = { 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0,
                          1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0,
                          1, 1, 1, 1, 1, 1};

            //loop of a 1D array for array length//                                                                                                                            
            for (int j = 0; j < inf.Length-1; j++)
            {
                //sets board [i to specific point, j=array pattern]
                    board[19 ,j+7].FutureState = inf[j];   
            }
            updateGrid();
        }

        //--save & load--\\

        //save file stream//
        public void Save()
        {

            //deactivates timer when save is called//
            tmGen.Enabled = false;

            //loops through current board state [i,j], writes to file as comma seperated value//
            for(int i = 0; i< ROWS; i++)
            {
                for(int j=0; j<COLS; j++)
                {
                    Writer.Write(board[i, j].IsAlive + ",");
                }
                Writer.WriteLine();
            }

        }

        //stream load files//
        private void load()
        {
            tmGen.Enabled = false;
            
            for (int i = 0; i < ROWS; i++)
            {
                //stores file read into the program as a comma seperated array
                string[] line = ReadIn.ReadLine().Split(',');

                //loop to load pattern to board//
                for(int j = 0; j < COLS; j++)
                {
                    //assigns array to future state when pattern is loaded into program//
                    board[i, j].FutureState = int.Parse(line[j]);

                    //converts age of cells loaded in back to first generation
                    board[i, j].Age = 0;
                } 
            }

        }

        //Find Generation through text//
        public void SpecGen()
        {

            ResetGrid(true);
            int spec;//variable declaration

            Int32.TryParse(txtSpecGen.Text,out spec);//parse text from textbox//

            if(spec == 0)//spec cannot equal 0//
            {
                MessageBox.Show("Please insert a generation number greater than one!");
            }

            while (spec > 0)
            {
                NextGen();//calls next gen method//
                updateGrid();//calls updategrid method//
                baseLbl();//calls baselabel to update after each interval//
                spec--;//decrements spec counter during each pass//
            }
        }
          
        //--BUTTONS--\\

        //displays selected pattern to GOL grid//
        private void btnDisplay_Click(object sender, EventArgs e)
        {
            tmGen.Enabled = false;
            //when nothing is checked create grid if button is clicked//
            if (radPulse.Checked == false && radBeacon.Checked == false && radInfinite.Checked == false && radGenRandom.Checked == false)
            {
                MessageBox.Show("Please select pattern or click 'Generate Grid' ");
                
            }
            
            //if pulsar pattern is selected displays to GOl Board//
            if (radPulse.Checked == true)
            {
                ResetGrid(false);              
                pulsar();
                baseLbl();
            }

            //if beacon pattern is selected display to GOL board//
            if (radBeacon.Checked == true)
            {
                ResetGrid(false);
                beacon();
                baseLbl();
            }
            //if infinte growth selected display to GOL board//
            if (radInfinite.Checked == true)
            {
                ResetGrid(false);
                infinite();
                baseLbl();
            }
            //if random GOL is selected display gen 1 pattern//
            if (radGenRandom.Checked == true)
            {
                createGrid(true);
                NextGen();
                updateGrid();
                baseLbl();
            }
        }

        //generates clean grid resets everything//
        private void btnGenGrid_Click(object sender, EventArgs e)
        {
            //turns timer off 
            tmGen.Enabled = false;
            //resets grid
            ResetGrid(false);
        }

        //toggle generation//
        private void btntogTimer_Click(object sender, EventArgs e)
        {
            // if timer is not enabled start timer
            if (tmGen.Enabled == false)
            {
                tmGen.Enabled = true;          
            }
            //else stop timer
            else tmGen.Enabled = false;

        }

        //loading--saving files//
        private void btnSelect_Click(object sender, EventArgs e)
        {
            //turns timer off on click so program stops running in background while file is loaded//
            tmGen.Enabled = false;

            //makes sure either save or load is checked//
            if(radSave.Checked == false && radLoad.Checked == false)
            {
                MessageBox.Show("Please select to save or load a file");
            }

            //if radio save is checked//
            if (radSave.Checked == true)
            {
                //if no buttons are selected error message//
                if (radPulse.Checked == false && radBeacon.Checked == false && radInfinite.Checked == false && radGenRandom.Checked == false)
                {
                    MessageBox.Show("Please click generate grid, select a pattern, or load a pattern to save");
                }
                else
                {
                    //saves file if user inputs a name in the dialog box//
                    try
                    {
                        saveFile.InitialDirectory = Directory.GetCurrentDirectory() + "/DialogPrompts";
                        saveFile.ShowDialog();
                        Writer = new StreamWriter(saveFile.FileName);
                        Save();
                        Writer.Close();
                    }
                    //must have save name file to save//
                    catch
                    {
                        MessageBox.Show("Requires file name to save!");
                    }
                }

            }
            //if radio load is checked//
            else if (radLoad.Checked == true)
            {
                //makes sure csv file is selected//
                try
                {
                    ResetGrid(false);//creates empty grid on load//
                    openFile.InitialDirectory = Directory.GetCurrentDirectory() + "/DialogPrompts";// gets current directory and goes into Saves
                    openFile.ShowDialog();// shows dialog box
                    ReadIn = new StreamReader(openFile.FileName);// File in refrences the file chosen
                    load();//calls load method//
                    updateGrid();// draws the board         
                    baseLbl();//sets labels to given values//
                    ReadIn.Close();//closes streamreader//
                }
                catch
                {
                    MessageBox.Show("Please choose a csv file");
                }

            }
                
        }

        //search generation button//
        private void btnSpecificGen_Click(object sender, EventArgs e)
        {
           //calls specgen() when button is clicked//
            SpecGen();
        }


        // --TIMER-- \\

        //keeps track of generations over time//
        private void tmGen_Tick(object sender, EventArgs e)
        {
            NextGen();//calls next gen method//
            updateGrid();//calls updategrid method//
            baseLbl();//calls baselabel to update after each interval//
        }

        //creates labels on load//
        private void GOLBoard_Load(object sender, EventArgs e)
        {
            ResetGrid(false);//onload resets labels and creates empty grid//
            
        }

    }
}
