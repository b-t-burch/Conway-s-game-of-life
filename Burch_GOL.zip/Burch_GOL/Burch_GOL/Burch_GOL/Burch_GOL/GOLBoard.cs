﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/// <summary>
/// Brendan Burch | 244 | 03.07.2018|
/// 
/// GAME OF LIFE: Make a  grid of alive and dead cells generated randomly, 
/// alive and dead cells determined by value of neighboring cells
/// 
/// </summary>

namespace Burch_GOL
{
    public partial class GOLBoard : Form
    {
        private Graphics gr; //graphics object//
        private Pen pen; //pen object//
        private Brush brush;//brush object//

        public const int ROWS = 42;//constant variable for 42 rows//
        public const int COLS = 62;//constant variable for 62 columns//

        public const int RECT_WIDTH = 9;//constant var for dimension//
        public const int RECT_HEIGHT = 9;//constant var for dimension//

        //two dimensional array of cells representing the grid//
        public GOLCell[,] board;

        //random generator
        public Random gen;

        //alive and dead cell counters//
        private int aliveCells;
        private int deadCells;
        
        

        //main method//
        public GOLBoard()
        {
            InitializeComponent();


            gr = panGrid.CreateGraphics();//creates graphics//

            board = new GOLCell[ROWS,COLS];//instantiate 2D array//
            pen = new Pen(Color.Black); //instantiate pen with color//
            brush = new SolidBrush(Color.White);//instantiate brush with color//

            gen = new Random();//instantiated random generator//
        }

        //Creates grid using loops//
        public void createGrid(bool genRandom)
        {
            for(int i = 0; i<ROWS; i++) // represents y coordinates on grid//
            {
                for(int j=0; j<COLS; j++) //represents x coordinates on grid//
                {
                    //creates new rectangle with given values//
                    Rectangle rect = new Rectangle(j * RECT_WIDTH, i * RECT_HEIGHT, RECT_HEIGHT, RECT_WIDTH);
                    gr.FillRectangle(brush, rect);//fills rectangle//
                    gr.DrawRectangle(pen, rect);//draws cells//

                    bool alive;
                    //determines if a cell is alive or dead//
                    if (genRandom == true)
                    {
                        alive = determineCellLife();
                    }
                    else
                    {
                        alive = false;
                    }
                    


                    //creates new GOL object//                 
                    board[i, j] = new GOLCell();
                    board[i, j].Cell = rect;
                    board[i, j].IsAlive = alive;

                }
            }
        }
        //Updates grid
        //paints alive cells yellow; adds alive cells to counter lable
        //paints dead cells white; adds dead cells to dead counter lable
        
        public void updateGrid()
        {
            SolidBrush yellowBrush = new SolidBrush(Color.Yellow);
            SolidBrush whiteBrush = new SolidBrush(Color.White);
            panGrid.Controls.Clear();

            aliveCells = 0;
            deadCells = 0;
            for (int i = 0; i < ROWS; i++)
            {
                for (int j = 0; j < COLS; j++)
                {
                    if (board[i, j].IsAlive == false)
                    {
                        gr.FillRectangle(yellowBrush, board[i, j].Cell);
                        aliveCells++;
                        lblaliveCells.Text = "Alive Cells: " + aliveCells;
                    }
                    else
                    {
                        gr.FillRectangle(whiteBrush, board[i, j].Cell);
                        deadCells++;
                        lbldeadCells.Text ="Dead Cells: " + deadCells;
                    }
                    gr.DrawRectangle(pen, board[i, j].Cell);
                }
            }   
        }

        //method to determine cell life01
        //returns alive or dead as a bool1ean statement to create grade//
       public bool determineCellLife()
        {
            bool alive;
            int i = gen.Next(0,2);
            if ( i != 1)
            {
                alive = true;
            }
            else
            {
                alive = false;
            }
            return alive;
        }


        //event handler for when generate random grid is clicked//
        private void btnGenGrid_Click(object sender, EventArgs e)
        {
            //creates empty grid by calling CreateGrid method//
            createGrid(false);
            
        }
        //event handler for generate random cells
        //calls updategrid method
        private void btnGenRandom_Click(object sender, EventArgs e)
        {
            createGrid(true);
            updateGrid();
        }

        private void panGrid_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
