﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Burch_GOL
{   //creates new GOL Cell Class
    public class GOLCell
    {
             //GOLCell class//
             // Memory space for Rectangle cell//
             //bool isAlive to determine whether neighboring cells are alive or dead//
       
      
          private Rectangle cell;
          //encapsulation fills in data of rectangle cell//
          public Rectangle Cell { get => cell; set => cell = value; }


          //variable to check if cell is alive or dead//
          private bool isAlive;
          //encapsulation checks to see if a cell is alive or dead//
          public bool IsAlive { get => isAlive; set => isAlive = value; }

            //GOLCell constructor
            public GOLCell()
            {
                
                Cell = new Rectangle();
                IsAlive = false;
            }
                
       

    


    }
}
