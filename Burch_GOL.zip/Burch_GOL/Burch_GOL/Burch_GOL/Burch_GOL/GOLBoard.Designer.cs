﻿namespace Burch_GOL
{
    partial class GOLBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panGrid = new System.Windows.Forms.Panel();
            this.btnGenGrid = new System.Windows.Forms.Button();
            this.btnGenRandom = new System.Windows.Forms.Button();
            this.lblKey = new System.Windows.Forms.Label();
            this.lblaliveCells = new System.Windows.Forms.Label();
            this.lbldeadCells = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // panGrid
            // 
            this.panGrid.Location = new System.Drawing.Point(3, 3);
            this.panGrid.Name = "panGrid";
            this.panGrid.Size = new System.Drawing.Size(650, 400);
            this.panGrid.TabIndex = 0;
            this.panGrid.Paint += new System.Windows.Forms.PaintEventHandler(this.panGrid_Paint);
            // 
            // btnGenGrid
            // 
            this.btnGenGrid.Location = new System.Drawing.Point(699, 12);
            this.btnGenGrid.Name = "btnGenGrid";
            this.btnGenGrid.Size = new System.Drawing.Size(129, 39);
            this.btnGenGrid.TabIndex = 1;
            this.btnGenGrid.Text = "Generate Grid";
            this.btnGenGrid.UseVisualStyleBackColor = true;
            this.btnGenGrid.Click += new System.EventHandler(this.btnGenGrid_Click);
            // 
            // btnGenRandom
            // 
            this.btnGenRandom.Location = new System.Drawing.Point(699, 100);
            this.btnGenRandom.Name = "btnGenRandom";
            this.btnGenRandom.Size = new System.Drawing.Size(129, 49);
            this.btnGenRandom.TabIndex = 2;
            this.btnGenRandom.Text = "Generate Random ";
            this.btnGenRandom.UseVisualStyleBackColor = true;
            this.btnGenRandom.Click += new System.EventHandler(this.btnGenRandom_Click);
            // 
            // lblKey
            // 
            this.lblKey.AutoSize = true;
            this.lblKey.BackColor = System.Drawing.Color.Cyan;
            this.lblKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblKey.Location = new System.Drawing.Point(12, 406);
            this.lblKey.Name = "lblKey";
            this.lblKey.Size = new System.Drawing.Size(43, 20);
            this.lblKey.TabIndex = 3;
            this.lblKey.Text = "Key :";
            // 
            // lblaliveCells
            // 
            this.lblaliveCells.AutoSize = true;
            this.lblaliveCells.BackColor = System.Drawing.Color.Cyan;
            this.lblaliveCells.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaliveCells.ForeColor = System.Drawing.Color.Yellow;
            this.lblaliveCells.Location = new System.Drawing.Point(15, 440);
            this.lblaliveCells.Name = "lblaliveCells";
            this.lblaliveCells.Size = new System.Drawing.Size(88, 20);
            this.lblaliveCells.TabIndex = 4;
            this.lblaliveCells.Text = "Alive Cells :";
            // 
            // lbldeadCells
            // 
            this.lbldeadCells.AutoSize = true;
            this.lbldeadCells.BackColor = System.Drawing.Color.Cyan;
            this.lbldeadCells.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldeadCells.ForeColor = System.Drawing.Color.White;
            this.lbldeadCells.Location = new System.Drawing.Point(15, 467);
            this.lbldeadCells.Name = "lbldeadCells";
            this.lbldeadCells.Size = new System.Drawing.Size(94, 20);
            this.lbldeadCells.TabIndex = 5;
            this.lbldeadCells.Text = "Dead Cells :";
            // 
            // GOLBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(869, 526);
            this.Controls.Add(this.lbldeadCells);
            this.Controls.Add(this.lblaliveCells);
            this.Controls.Add(this.lblKey);
            this.Controls.Add(this.btnGenRandom);
            this.Controls.Add(this.btnGenGrid);
            this.Controls.Add(this.panGrid);
            this.Name = "GOLBoard";
            this.Text = "Game of Life Board";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panGrid;
        private System.Windows.Forms.Button btnGenGrid;
        private System.Windows.Forms.Button btnGenRandom;
        private System.Windows.Forms.Label lblKey;
        private System.Windows.Forms.Label lblaliveCells;
        private System.Windows.Forms.Label lbldeadCells;
    }
}

