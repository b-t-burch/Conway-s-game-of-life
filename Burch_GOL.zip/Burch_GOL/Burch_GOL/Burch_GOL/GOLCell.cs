﻿using System.Drawing;

namespace Burch_GOL
{   //creates new GOL Cell Class
    public class GOLCell
    {
             //GOLCell class//
             // Memory space for Rectangle cell//
             //bool isAlive to determine whether neighboring cells are alive or dead//
       
      
         private Rectangle cell;
         //encapsulation fills in data of rectangle cell//
         public Rectangle Cell { get => cell; set => cell = value; }

         //variable to check if cell is alive or dead//
         private int isAlive;
         //encapsulation checks to see if a cell is alive or dead//
         public int IsAlive { get => isAlive; set => isAlive = value; }

        //finds if cell is alive or dead in the future//
        private int futureState;
        //encapsulation of futurestate checks if cell is alive or dead in the future//
        public int FutureState { get => futureState; set => futureState = value; }

        //age of the cell//
        private int age;
        //encapsulation of age checks the age of the cell//
        public int Age { get => age; set => age = value; }



        //GOLCell constructor//
        public GOLCell()
        {
                
            Cell = new Rectangle();
            IsAlive = 0;
            futureState = 0;
            age = 0;
        }
        
        //method changes age and isAlive based on futureState then resets futureState// 
        public void ChangeFutureToCurrent()
        {
            //if future state is dead, all values are zero//
            if(futureState == 0)
            {
                isAlive = 0;
                age = 0; 
            }
            //if futurestate is alive, increments age
            else if(futureState==1)
            {
                isAlive = 1;
                age++;
            }
            futureState = 0;


        }


        //method returns the color of the cell based on age//
        public Color DetermineColor()
        {
            Color cell;
            switch (age)
            {
                case 0:
                    cell = Color.White;
                    break;
                case 1:
                    cell = Color.Yellow;
                    break;
                case 2:
                    cell = Color.Green;
                    break;
                case 3:
                    cell = Color.Blue;
                    break;
                case 4:
                    cell = Color.Magenta;
                    break;
                default:
                    cell = Color.Red;
                    break;
            }
            return cell;
        }
       

    


    }
}
