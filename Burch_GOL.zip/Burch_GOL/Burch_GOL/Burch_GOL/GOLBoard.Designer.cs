﻿namespace Burch_GOL
{
    partial class GOLBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panGrid = new System.Windows.Forms.Panel();
            this.btnGenGrid = new System.Windows.Forms.Button();
            this.lblKey = new System.Windows.Forms.Label();
            this.tmGen = new System.Windows.Forms.Timer(this.components);
            this.lblGen = new System.Windows.Forms.Label();
            this.lblRed = new System.Windows.Forms.Label();
            this.lblGreen = new System.Windows.Forms.Label();
            this.lblBlue = new System.Windows.Forms.Label();
            this.lblMagenta = new System.Windows.Forms.Label();
            this.lblYellow = new System.Windows.Forms.Label();
            this.lblWhite = new System.Windows.Forms.Label();
            this.grpGenBox = new System.Windows.Forms.GroupBox();
            this.radGenRandom = new System.Windows.Forms.RadioButton();
            this.btntogTimer = new System.Windows.Forms.Button();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.radInfinite = new System.Windows.Forms.RadioButton();
            this.radBeacon = new System.Windows.Forms.RadioButton();
            this.radPulse = new System.Windows.Forms.RadioButton();
            this.radSave = new System.Windows.Forms.RadioButton();
            this.saveFile = new System.Windows.Forms.SaveFileDialog();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radLoad = new System.Windows.Forms.RadioButton();
            this.btnSelect = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSpecificGen = new System.Windows.Forms.Button();
            this.txtSpecGen = new System.Windows.Forms.TextBox();
            this.grpGenBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panGrid
            // 
            this.panGrid.BackColor = System.Drawing.Color.White;
            this.panGrid.Location = new System.Drawing.Point(3, 3);
            this.panGrid.Name = "panGrid";
            this.panGrid.Size = new System.Drawing.Size(550, 380);
            this.panGrid.TabIndex = 0;
            // 
            // btnGenGrid
            // 
            this.btnGenGrid.BackColor = System.Drawing.Color.Magenta;
            this.btnGenGrid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenGrid.ForeColor = System.Drawing.Color.Black;
            this.btnGenGrid.Location = new System.Drawing.Point(600, 389);
            this.btnGenGrid.Name = "btnGenGrid";
            this.btnGenGrid.Size = new System.Drawing.Size(129, 39);
            this.btnGenGrid.TabIndex = 1;
            this.btnGenGrid.Text = "Generate Grid";
            this.btnGenGrid.UseVisualStyleBackColor = false;
            this.btnGenGrid.Click += new System.EventHandler(this.btnGenGrid_Click);
            // 
            // lblKey
            // 
            this.lblKey.AutoSize = true;
            this.lblKey.BackColor = System.Drawing.Color.Black;
            this.lblKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblKey.Location = new System.Drawing.Point(-1, 406);
            this.lblKey.Name = "lblKey";
            this.lblKey.Size = new System.Drawing.Size(43, 20);
            this.lblKey.TabIndex = 3;
            this.lblKey.Text = "Key :";
            // 
            // tmGen
            // 
            this.tmGen.Interval = 40;
            this.tmGen.Tick += new System.EventHandler(this.tmGen_Tick);
            // 
            // lblGen
            // 
            this.lblGen.AutoSize = true;
            this.lblGen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGen.ForeColor = System.Drawing.Color.Cyan;
            this.lblGen.Location = new System.Drawing.Point(59, 406);
            this.lblGen.Name = "lblGen";
            this.lblGen.Size = new System.Drawing.Size(97, 20);
            this.lblGen.TabIndex = 6;
            this.lblGen.Text = "Generation :";
            // 
            // lblRed
            // 
            this.lblRed.AutoSize = true;
            this.lblRed.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRed.ForeColor = System.Drawing.Color.Red;
            this.lblRed.Location = new System.Drawing.Point(268, 426);
            this.lblRed.Name = "lblRed";
            this.lblRed.Size = new System.Drawing.Size(149, 20);
            this.lblRed.TabIndex = 7;
            this.lblRed.Text = "# Red Cells(5+gen):";
            // 
            // lblGreen
            // 
            this.lblGreen.AutoSize = true;
            this.lblGreen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGreen.ForeColor = System.Drawing.Color.Lime;
            this.lblGreen.Location = new System.Drawing.Point(59, 470);
            this.lblGreen.Name = "lblGreen";
            this.lblGreen.Size = new System.Drawing.Size(163, 20);
            this.lblGreen.TabIndex = 8;
            this.lblGreen.Text = "# Green Cells(Gen 2):";
            // 
            // lblBlue
            // 
            this.lblBlue.AutoSize = true;
            this.lblBlue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBlue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblBlue.Location = new System.Drawing.Point(59, 490);
            this.lblBlue.Name = "lblBlue";
            this.lblBlue.Size = new System.Drawing.Size(150, 20);
            this.lblBlue.TabIndex = 9;
            this.lblBlue.Text = "# Blue Cells(Gen 3):";
            // 
            // lblMagenta
            // 
            this.lblMagenta.AutoSize = true;
            this.lblMagenta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMagenta.ForeColor = System.Drawing.Color.Magenta;
            this.lblMagenta.Location = new System.Drawing.Point(59, 510);
            this.lblMagenta.Name = "lblMagenta";
            this.lblMagenta.Size = new System.Drawing.Size(181, 20);
            this.lblMagenta.TabIndex = 10;
            this.lblMagenta.Text = "# Magenta Cells(Gen 4):";
            // 
            // lblYellow
            // 
            this.lblYellow.AutoSize = true;
            this.lblYellow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYellow.ForeColor = System.Drawing.Color.Yellow;
            this.lblYellow.Location = new System.Drawing.Point(59, 450);
            this.lblYellow.Name = "lblYellow";
            this.lblYellow.Size = new System.Drawing.Size(144, 20);
            this.lblYellow.TabIndex = 11;
            this.lblYellow.Text = "# of Yellow(Gen 1):";
            // 
            // lblWhite
            // 
            this.lblWhite.AutoSize = true;
            this.lblWhite.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWhite.ForeColor = System.Drawing.Color.White;
            this.lblWhite.Location = new System.Drawing.Point(59, 426);
            this.lblWhite.Name = "lblWhite";
            this.lblWhite.Size = new System.Drawing.Size(160, 20);
            this.lblWhite.TabIndex = 12;
            this.lblWhite.Text = "# White Cells(Empty):";
            // 
            // grpGenBox
            // 
            this.grpGenBox.Controls.Add(this.radGenRandom);
            this.grpGenBox.Controls.Add(this.btntogTimer);
            this.grpGenBox.Controls.Add(this.btnDisplay);
            this.grpGenBox.Controls.Add(this.radInfinite);
            this.grpGenBox.Controls.Add(this.radBeacon);
            this.grpGenBox.Controls.Add(this.radPulse);
            this.grpGenBox.ForeColor = System.Drawing.Color.White;
            this.grpGenBox.Location = new System.Drawing.Point(579, 3);
            this.grpGenBox.Name = "grpGenBox";
            this.grpGenBox.Size = new System.Drawing.Size(201, 168);
            this.grpGenBox.TabIndex = 13;
            this.grpGenBox.TabStop = false;
            this.grpGenBox.Text = "Type of Generation:";
            // 
            // radGenRandom
            // 
            this.radGenRandom.AutoSize = true;
            this.radGenRandom.Location = new System.Drawing.Point(75, 20);
            this.radGenRandom.Name = "radGenRandom";
            this.radGenRandom.Size = new System.Drawing.Size(88, 17);
            this.radGenRandom.TabIndex = 7;
            this.radGenRandom.TabStop = true;
            this.radGenRandom.Text = "Random Gen";
            this.radGenRandom.UseVisualStyleBackColor = true;
            // 
            // btntogTimer
            // 
            this.btntogTimer.BackColor = System.Drawing.Color.Lime;
            this.btntogTimer.ForeColor = System.Drawing.Color.Black;
            this.btntogTimer.Location = new System.Drawing.Point(11, 117);
            this.btntogTimer.Name = "btntogTimer";
            this.btntogTimer.Size = new System.Drawing.Size(139, 27);
            this.btntogTimer.TabIndex = 6;
            this.btntogTimer.Text = "Toggle Generation";
            this.btntogTimer.UseVisualStyleBackColor = false;
            this.btntogTimer.Click += new System.EventHandler(this.btntogTimer_Click);
            // 
            // btnDisplay
            // 
            this.btnDisplay.BackColor = System.Drawing.Color.Chartreuse;
            this.btnDisplay.ForeColor = System.Drawing.Color.Black;
            this.btnDisplay.Location = new System.Drawing.Point(11, 88);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(139, 23);
            this.btnDisplay.TabIndex = 5;
            this.btnDisplay.Text = "Display Pattern";
            this.btnDisplay.UseVisualStyleBackColor = false;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // radInfinite
            // 
            this.radInfinite.AutoSize = true;
            this.radInfinite.Location = new System.Drawing.Point(11, 65);
            this.radInfinite.Name = "radInfinite";
            this.radInfinite.Size = new System.Drawing.Size(96, 17);
            this.radInfinite.TabIndex = 3;
            this.radInfinite.TabStop = true;
            this.radInfinite.Text = "Infinite Growth:";
            this.radInfinite.UseVisualStyleBackColor = true;
            // 
            // radBeacon
            // 
            this.radBeacon.AutoSize = true;
            this.radBeacon.Location = new System.Drawing.Point(11, 42);
            this.radBeacon.Name = "radBeacon";
            this.radBeacon.Size = new System.Drawing.Size(65, 17);
            this.radBeacon.TabIndex = 2;
            this.radBeacon.TabStop = true;
            this.radBeacon.Text = "Beacon:";
            this.radBeacon.UseVisualStyleBackColor = true;
            // 
            // radPulse
            // 
            this.radPulse.AutoSize = true;
            this.radPulse.Location = new System.Drawing.Point(11, 19);
            this.radPulse.Name = "radPulse";
            this.radPulse.Size = new System.Drawing.Size(57, 17);
            this.radPulse.TabIndex = 1;
            this.radPulse.TabStop = true;
            this.radPulse.Text = "Pulsar:";
            this.radPulse.UseVisualStyleBackColor = true;
            // 
            // radSave
            // 
            this.radSave.AutoSize = true;
            this.radSave.ForeColor = System.Drawing.Color.White;
            this.radSave.Location = new System.Drawing.Point(11, 20);
            this.radSave.Name = "radSave";
            this.radSave.Size = new System.Drawing.Size(87, 17);
            this.radSave.TabIndex = 4;
            this.radSave.TabStop = true;
            this.radSave.Text = "Save Pattern";
            this.radSave.UseVisualStyleBackColor = true;
            // 
            // saveFile
            // 
            this.saveFile.DefaultExt = "csv";
            this.saveFile.RestoreDirectory = true;
            // 
            // openFile
            // 
            this.openFile.DefaultExt = "csv";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radLoad);
            this.groupBox1.Controls.Add(this.btnSelect);
            this.groupBox1.Controls.Add(this.radSave);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(580, 177);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 95);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "File options:";
            // 
            // radLoad
            // 
            this.radLoad.AutoSize = true;
            this.radLoad.ForeColor = System.Drawing.Color.White;
            this.radLoad.Location = new System.Drawing.Point(99, 20);
            this.radLoad.Name = "radLoad";
            this.radLoad.Size = new System.Drawing.Size(68, 17);
            this.radLoad.TabIndex = 5;
            this.radLoad.TabStop = true;
            this.radLoad.Text = "Load File";
            this.radLoad.UseVisualStyleBackColor = true;
            // 
            // btnSelect
            // 
            this.btnSelect.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnSelect.ForeColor = System.Drawing.Color.Black;
            this.btnSelect.Location = new System.Drawing.Point(47, 43);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(75, 23);
            this.btnSelect.TabIndex = 0;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = false;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSpecificGen);
            this.groupBox2.Controls.Add(this.txtSpecGen);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(580, 283);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(201, 100);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Select Specific Generation:";
            // 
            // btnSpecificGen
            // 
            this.btnSpecificGen.BackColor = System.Drawing.Color.Yellow;
            this.btnSpecificGen.ForeColor = System.Drawing.Color.Black;
            this.btnSpecificGen.Location = new System.Drawing.Point(12, 45);
            this.btnSpecificGen.Name = "btnSpecificGen";
            this.btnSpecificGen.Size = new System.Drawing.Size(161, 33);
            this.btnSpecificGen.TabIndex = 1;
            this.btnSpecificGen.Text = "Generate";
            this.btnSpecificGen.UseVisualStyleBackColor = false;
            this.btnSpecificGen.Click += new System.EventHandler(this.btnSpecificGen_Click);
            // 
            // txtSpecGen
            // 
            this.txtSpecGen.Location = new System.Drawing.Point(11, 19);
            this.txtSpecGen.Name = "txtSpecGen";
            this.txtSpecGen.Size = new System.Drawing.Size(161, 20);
            this.txtSpecGen.TabIndex = 0;
            // 
            // GOLBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(880, 543);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grpGenBox);
            this.Controls.Add(this.lblWhite);
            this.Controls.Add(this.lblYellow);
            this.Controls.Add(this.lblMagenta);
            this.Controls.Add(this.lblBlue);
            this.Controls.Add(this.lblGreen);
            this.Controls.Add(this.lblRed);
            this.Controls.Add(this.lblGen);
            this.Controls.Add(this.lblKey);
            this.Controls.Add(this.btnGenGrid);
            this.Controls.Add(this.panGrid);
            this.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.Name = "GOLBoard";
            this.Text = "Game of Life Board";
            this.Load += new System.EventHandler(this.GOLBoard_Load);
            this.grpGenBox.ResumeLayout(false);
            this.grpGenBox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panGrid;
        private System.Windows.Forms.Button btnGenGrid;
        private System.Windows.Forms.Label lblKey;
        private System.Windows.Forms.Timer tmGen;
        private System.Windows.Forms.Label lblGen;
        private System.Windows.Forms.Label lblRed;
        private System.Windows.Forms.Label lblGreen;
        private System.Windows.Forms.Label lblBlue;
        private System.Windows.Forms.Label lblMagenta;
        private System.Windows.Forms.Label lblYellow;
        private System.Windows.Forms.Label lblWhite;
        private System.Windows.Forms.GroupBox grpGenBox;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.RadioButton radSave;
        private System.Windows.Forms.RadioButton radInfinite;
        private System.Windows.Forms.RadioButton radBeacon;
        private System.Windows.Forms.RadioButton radPulse;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radLoad;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btntogTimer;
        private System.Windows.Forms.RadioButton radGenRandom;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSpecificGen;
        private System.Windows.Forms.TextBox txtSpecGen;
        public System.Windows.Forms.SaveFileDialog saveFile;
        public System.Windows.Forms.OpenFileDialog openFile;
    }
}

